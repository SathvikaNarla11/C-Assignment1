/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int ts;
    printf("Enter seconds : \n");
    scanf("%d",&ts);
    
    int h,m,s;
    h = ts/3600;
    int rh = ts%3600;
    printf("h : %d\n", h);
    m = rh/60;
    s = ts-(h*3600)-(m*60);
    printf("m : %d\n", m);
    printf("s : %d\n", s);
    printf("\n");
    printf("Time is : %02d:%02d:%02d",h,m,s);
}
