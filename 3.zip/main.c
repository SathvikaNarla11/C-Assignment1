/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    short int x;
    scanf("%hd",&x);
    printf("The value is : %hd\n", x);
    printf("The value is : 0x%hx\n", x);
    printf("The value is : 0%ho\n", x);
    
}

